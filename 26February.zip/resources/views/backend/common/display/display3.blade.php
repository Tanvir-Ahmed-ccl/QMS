@extends('layouts.display')
@section('title', trans('app.display_3'))

@section('content')
<div class="panel panel-primary">

    <div class="panel-heading">
        <div class="row">
            <div class="col-sm-12">
                <h3>{{ trans('app.display_3') }} <button class="pull-right btn btn-sm btn-primary" onclick="goFullscreen('fullscreen'); return false"><i class="fa fa-arrows-alt" aria-hidden="true"></i></button></h3>
                <span class="text-danger">(enable full-screen mode and wait 10 seconds to adjust the screen)</span>
            </div> 
        </div>
    </div> 

    <div class="panel-body" id="fullscreen">
    
      <div class="media row" style="height:60px;background:#3498db;margin-top:-20px;margin-bottom:20px">
        <div class="media-left hidden-xs">
          <img class="media-object" style="height:59px;" src="{{ asset(session('app.logo')) }}" alt="Logo">
        </div>
        <div class="media-body" style="color:#ffffff">
          <h4 class="media-heading" style="font-size:50px;line-height:60px"><marquee direction="{{ (!empty($setting->direction)?$setting->direction:null) }}">{{ (!empty($setting->message)?$setting->message:null) }}</marquee></h4> 
        </div>
      </div>

        <div class="row">  
           <div id="display3"></div>
        </div>


        <div class="panel-footer row" style="margin-top:10px">
          @include('backend.common.info')
          <span class="col-xs-10 text-left">@yield('info.powered-by')</span>
          <span class="col-xs-2 text-right">@yield('info.version')</span>
        </div>
    </div>  
</div>  
@endsection

@push('scripts')
<script type="text/javascript">  
$(document).ready(function(){
  //get previous token
  var view_token = [];
  var interval = 1000; 

  var display = function()
  {
      var width  = $(window).width();
      var height = $(window).height();
      var isFullScreen = document.fullScreen ||
      document.mozFullScreen ||
      document.webkitIsFullScreen || (document.msFullscreenElement != null);
      if (isFullScreen)
      {
        var width  = $(window).width();
        var height = $(window).height();
      } 

      $.ajax({
          type:'post',
          dataType:'json',
          url:'{{ URL::to("common/display3") }}',
          data:
          {
              _token: '<?php echo csrf_token() ?>',
              view_token: view_token,
              width: width,
              height: height
          },
          success:function(data){
            $("#display3").html(data.result); 

            view_token = (data.all_token).map(function(item){
                return {counter: item.counter, token  : item.token} 
            }); 

            //notification sound
            if (data.status)
            {  
              console.log("====> Next Calling");
              playSound(data);
            }
            else
            {
              console.log("====> Queue Serving");
            }
            setTimeout(display, data.interval);
         }
      });
  }; 

  setTimeout(display, interval);

  function playSound(data){
    var sounds = [];
    sounds.push(new Audio(`{{url('')}}/assets/sounds/start.mp3`));            

    if ((data.new_token.length > 0)) {

        data.new_token.map(function(item) {

          var tokenObject = item;
          var i = 0;
          const counter = tokenObject.counter.toString().replace(/\s/g, '');
          sounds.push(new Audio(`{{url('')}}/assets/sounds/en/counter.mp3`));
          
          while (i < counter.length) 
          {
            var char = counter.charAt(i).toLowerCase(); 
            sounds.push(new Audio(`{{url('')}}/assets/sounds/en/char/`+char+`.mp3`));
            i++;
          }

          const token = tokenObject.token.toString();
          i = 0;
          sounds.push(new Audio(`{{url('')}}/assets/sounds/en/token.mp3`));
          while (i < token.length) 
          {
            var char = token.charAt(i).toLowerCase(); 
            sounds.push(new Audio(`{{url('')}}/assets/sounds/en/char/`+char+`.mp3`));
            i++;
          }

          console.log(`======> New TOken \n Counter: ${counter} \n Token: ${token}`);
      });
    };

    playAudio(sounds);

    async function playAudio(sounds){
      for (var i = 0; i < (sounds).length; i++) {
        const item = sounds[i];
        await new Promise((resolve) => {
          item.onended = resolve;
          console.log("+++++  Sounds Playing  +++++");
          item.play();
          console.log("+++++  Sounds Good  +++++");
        });

      }
    }
  }

});
</script>
@endpush


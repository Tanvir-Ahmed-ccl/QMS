<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SmsHistory extends Model
{
    protected $table = "sms_history"; 
    
	public $timestamps = false;
}

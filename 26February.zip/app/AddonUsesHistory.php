<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AddonUsesHistory extends Model
{
    //
}

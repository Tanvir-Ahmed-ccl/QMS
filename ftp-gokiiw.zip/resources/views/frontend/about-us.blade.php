@extends('frontend.layouts.master')


@section('content')
    <div class="container mb-5 px-5">


        <div class="row align-items-center" style="min-height: 50vh">
            <div class="col text-center">
                <h1 class="text-secondary fw-bolder">Gokiiw Overview</h1>
            </div>
        </div>
            

        <div class="row align-items-center min-vh-100 justify-content-between">
            <div class="col-lg-6">
                <h1 class="mb-4">Then</h1>

                <h5>Qminder started in 2011, as part of the Estonia-based Garage48 startup hackathon. A small team of developers asked themselves two questions:
                    <br><br>  Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione praesentium exercitationem neque blanditiis, libero nisi perferendis atque placeat natus quam?
                </h5>
            </div>

            <div class="col-lg-6">
                <img src="{{ asset('frontend/1.webp') }}" alt="" width="500" class="img-fluid">
            </div>

        </div>
            

        <div class="row min-vh-100 align-items-center justify-content-between">
            <div class="col-lg-6">
                <h1 class="mb-4">Then</h1>

                <h5>
                    Now, Qminder is a B2B SaaS company with an international presence. Over the years, some of the world’s most influential companies — Uber, AT&T, Verizon — have recruited Qminder to solve their customer experience problems.
                </h5>
            </div>

            <div class="col-lg-6 order-first">
                <img src="{{ asset('frontend/2.webp') }}" alt="" width="400" class="img-fluid">
            </div>
        
        </div>



        <div class="row gx-2 my-5 py-5 align-items-center justify-content-center">
            <div class="col-md text-center">
                <h1 class="mb-3 fw-bolder text-success">2011</h1>
                <h5>Gokiiw launched</h5>
            </div>

           <div class="col-md text-center">
                <h1 class="mb-3 fw-bolder text-success">40+</h1>
                <h5>Gokiiw launched</h5>
            </div>

            <div class="col-md text-center">
                <h1 class="mb-3 fw-bolder text-success">70M+</h1>
                <h5>Gokiiw launched</h5>
            </div>
        
        </div>

    </div>


@endsection
@extends('auth.layouts.auth')

@section('content')
  <div class="row w-100 mx-0">
      <div class="col-lg-4 mx-auto">
          <div class="auth-form-light text-left py-5 px-4 px-sm-5 text-center">
              <div class="brand-logo text-center">
                  {{-- <img src="{{ asset('backend/images/logo.svg') }}"
                  alt="logo"> --}}
                  <a class="nav-link" href="{{ url('') }}">
                    <img src="{{ asset(getSetting('site_logo')) }}" title="" alt="">
                      {{-- <span class="text-primary fw-bolder fs-2">QMS</span> <span> System</span> --}}
                  </a>
              </div>
              <h4>Reset Your Password!</h4>

              @if(session('status'))
                  <div class="alert alert-success" role="alert">
                      {{ session('status') }}
                  </div>
              @endif
              <form method="POST" action="{{ route('password.email') }}">
                  @csrf

                  <div class="row mb-3 mt-3">

                      <div class="col-md-12">
                          <input id="email" placeholder="Type Email" type="email" class="form-control form-control-lg @error('email') is-invalid @enderror"
                              name="email" value="{{ old('email') }}" required autocomplete="email"
                              autofocus>

                          @error('email')
                              <span class="invalid-feedback" role="alert">
                                  <strong>{{ $message }}</strong>
                              </span>
                          @enderror
                      </div>
                  </div>

                  <div class="row mb-0">
                      <div class="col-md-6 offset-md-4">
                          <button type="submit" class="btn btn-primary text-white">
                              {{ __('Send Password Reset Link') }}
                          </button>
                      </div>
                  </div>
              </form>
          </div>
      </div>
  </div>
@endsection


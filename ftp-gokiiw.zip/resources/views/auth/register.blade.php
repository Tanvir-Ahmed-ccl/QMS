@extends('auth.layouts.auth')

@section('title', 'Registration')

@section('css')
    <style>
        .BDC_CaptchaImageDiv, .BDC_CaptchaIconsDiv {
            float: left;
        }
    </style>
@endsection

@section('content')

<div class="row w-100 mx-0">
    <div class="col-lg-4 mx-auto">
      <div class="auth-form-light text-left py-5 px-4 px-sm-5">
        <div class="brand-logo text-center">
            <a class="nav-link" href="{{ url('') }}">
                <img src="{{ asset(getSetting('site_logo')) }}" title="" alt="">
                {{-- <span class="text-primary fw-bolder fs-2">QMS</span> <span> System</span> --}}
            </a>
          </div>
        <h4>New here?</h4>
        <h6 class="font-weight-light">Signing up is easy. It only takes a few steps</h6>
        @if($errors->any())
            {!! implode('', $errors->all('<div class="alert alert-danger">:message</div>')) !!}
        @endif
        <form class="pt-3" method="POST" action="{{ route('register') }}">
            @csrf
          <div class="form-group">
            <input type="text" class="form-control form-control-lg" id="exampleInputUsername1" placeholder="Name" name="name" value="{{ old('name') }}">
          </div>
          <div class="form-group">
            <input type="email" name="email" class="form-control form-control-lg" id="exampleInputEmail1" placeholder="Email" value="{{ old('email') }}">
          </div>
          <div class="form-group">
            <input type="password" name="password" class="form-control form-control-lg" id="exampleInputPassword1" placeholder="Password" value="{{ old('password') }}">
          </div>
          <div class="form-group">
            <input type="password" name="password_confirmation" class="form-control form-control-lg" id="exampleInputPassword1" placeholder="Confirm Password" value="{{ old('password_confirmation') }}">
          </div>
          <div class="form-group">
            {!! NoCaptcha::renderJs() !!}
            {!! NoCaptcha::display() !!}
        </div>
          {{-- <div class="mb-4">
            <div class="form-check">
              <label class="form-check-label text-muted">
                <input type="checkbox" class="form-check-input">
                I agree to all Terms & Conditions
              </label>
            </div>
          </div> --}}
          <div class="mt-3 text-center">
            <button type="submit" class="btn btn-block btn-primary btn-lg font-weight-medium auth-form-btn text-white">SIGN UP</button>
          </div>
          <div class="text-center mt-4 font-weight-light">
            Already have an account? <a href="{{ route('login') }}" class="text-primary">Login</a>
          </div>
        </form>
      </div>
    </div>
  </div>
@endsection
@section('scripts')
<script>
    $("a:contains('BotDetect CAPTCHA Library for Laravel')").remove();
</script>
@endsection


<?php $__env->startSection('title', trans('app.new_sms')); ?>
 
<?php $__env->startSection('content'); ?>
<div class="panel panel-primary">

    <div class="panel-heading">
        <div class="row">
            <div class="col-sm-12 text-left">
                <h3><?php echo e(trans('app.new_sms')); ?></h3>
            </div> 
        </div>
    </div>

    <div class="panel-body"> 
        <?php echo e(Form::open(['url' => 'admin/sms/new', 'files' => true, 'class'=>'col-md-7 col-sm-8'])); ?>


            <div class="form-group <?php $__errorArgs = ['to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label for="to"><?php echo e(trans('app.mobile')); ?> <i class="text-danger">*</i> </label>
                <input type="text" name="to" id="to" class="form-control" placeholder="<?php echo e(trans('app.mobile')); ?>" value="<?php echo e(old('to')); ?>">
                <span class="text-danger"><?php echo e($errors->first('to')); ?></span>
            </div>

            <div class="form-group <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label for="message"><?php echo e(trans('app.message')); ?>  <i class="text-danger">*</i> </label>
                <textarea name="message" id="message" class="form-control" placeholder="<?php echo e(trans('app.message')); ?>"><?php echo e(old('message')); ?></textarea>
                <span class="text-danger"><?php echo e($errors->first('message')); ?></span>
            </div>
 
            <div class="form-group">
                <button class="button btn btn-info" type="reset"><span><?php echo e(trans('app.reset')); ?></span></button>
                <button class="button btn btn-success" type="submit"><span><?php echo e(trans('app.send')); ?></span></button>
            </div> 

        <?php echo e(Form::close()); ?>

    </div>
</div>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\main\resources\views/backend/admin/sms/form.blade.php ENDPATH**/ ?>
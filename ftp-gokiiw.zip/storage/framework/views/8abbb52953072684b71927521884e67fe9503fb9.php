<?php $__env->startSection('content'); ?>
    <div class="container mb-5">
        <div class="row my-5 justify-content-center align-items-center" style="min-height: 80vh;">
            
            <div class="row align-items-center" style="min-height: 40vh">
                <div class="col text-center">
                    <h1 class="text-secondary">Success Stories</h1>
                </div>
            </div>
            
            <?php for($i=0; $i<=10; $i++): ?>
            <div class="col-lg-4 mb-4">
                <div class="card shadow">
                    <img src="https://www.qminder.com/resources/img/blog/plate-by-plate/plate-by-plate-staff.png" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Blog title</h5>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                        <a href="#" class="btn btn-outline-dark">See More <i class="bi bi-arrow-right"></i> </a>
                    </div>
                </div>
            </div>
            <!-- col-lg-6 -->
            <?php endfor; ?>

           

            


            
        </div>

    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gigsoft.net/public_html/resources/views/frontend/blog.blade.php ENDPATH**/ ?>
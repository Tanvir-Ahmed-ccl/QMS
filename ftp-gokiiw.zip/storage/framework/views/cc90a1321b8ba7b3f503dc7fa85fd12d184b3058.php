
<?php $__env->startSection('title', trans('app.inbox_message')); ?>


<?php $__env->startSection('content'); ?>
<div class="panel panel-primary">

    <div class="panel-heading">
        <div class="row">
            <div class="col-sm-12 text-left">
                <h3><?php echo e(trans('app.inbox_message')); ?></h3>
            </div> 
        </div>
    </div>

    <div class="panel-body">
        <table class="dataTables-server display table table-bordered" width="100%" cellspacing="0">
            <thead>
                <tr>
                    <th>#</th> 
                    <th><?php echo e(trans('app.photo')); ?> </th>
                    <th><?php echo e(trans('app.sender')); ?> </th>
                    <th><?php echo e(trans('app.subject')); ?></th>
                    <th><?php echo e(trans('app.message')); ?></th>
                    <th><?php echo e(trans('app.attachment')); ?></th>
                    <th> 
                        <label><?php echo e(trans('app.status')); ?></label><br/>
                        <select id="status" class="select2 filter">
                            <option value=""><?php echo e(trans('app.status')); ?></option>
                            <option value="1"><?php echo e(trans('app.seen')); ?></option>
                            <option value="'0'"><?php echo e(trans('app.not_seen')); ?></option>
                        </select> 
                    </th> 
                    <th><?php echo e(trans('app.date')); ?></th>
                    <th width="80"><i class="fa fa-cogs"></i></th>
                </tr>
            </thead>  
        </table>
    </div> 
</div>  
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?> 
<script> 
$(document).ready(function(){
    // DATATABLE
    drawDataTable();

    $("body").on("change",".filter", function(){
        drawDataTable();
    });

    function drawDataTable()
    { 
        var oTable = $('.dataTables-server');
        oTable.DataTable().destroy();
        var oTable = $('.dataTables-server').DataTable({
            responsive: true, 
            processing: true,
            serverSide: true,
            ajax: {
                url:"<?php echo e(url('common/message/inbox/data')); ?>",
                dataType: 'json',
                type    : 'post',
                data    : {
                    _token : '<?php echo e(csrf_token()); ?>', 
                    search: {
                        status     : $('#status').val(),
                    }
                }
            },
            columns: [ 
                { data: 'serial' },
                { data: 'photo' },
                { data: 'sender' },
                { data: 'subject' },
                { data: 'message' },
                { data: 'attachment' },
                { data: 'receiver_status' },
                { data: 'datetime' },
                { data: 'options' }
            ],
            order: [ [0, 'desc'] ], 
            select    : true,
            pagingType: "full_numbers",
            lengthMenu: [[25, 50, 100, 150, 200, 500, -1], [25, 50, 100, 150, 200, 500, "All"]],
            dom: "<'row'<'col-sm-4'l><'col-sm-4 text-center'B><'col-sm-4'f>><'row'<'col-sm-12't>><'row'<'col-sm-6'i><'col-sm-6'p>>", 
            columnDefs: [
                { "orderable": false, "targets": [1,6,8] }
            ],
            buttons: [
                { extend:'copy', footer:true, text:'<i class="fa fa-copy"></i>', className:'btn-sm',exportOptions:{columns:':visible'}},
                { extend: 'print', footer:true, text:'<i class="fa fa-print"></i>', className:'btn-sm', exportOptions: { columns: ':visible',  modifier: { selected: null } }},  
                { extend: 'print', footer:true, text:'<i class="fa fa-print"></i>  Selected', className:'btn-sm', exportOptions:{columns: ':visible'}},  
                { extend:'excel',  footer:true, text:'<i class="fa fa-file-excel-o"></i>', className:'btn-sm',exportOptions:{columns:':visible'}},
                { extend:'pdf',  footer:true, text:'<i class="fa fa-file-pdf-o"></i>',  className:'btn-sm',exportOptions:{columns:':visible'}},
                { extend:'colvis', footer:true, text:'<i class="fa fa-eye"></i>',className:'btn-sm'} 
            ]
        });
    }
}); 
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\main\resources\views/backend/common/message/inbox.blade.php ENDPATH**/ ?>
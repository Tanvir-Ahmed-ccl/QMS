
<?php $__env->startSection('title', trans('app.update_counter')); ?>
 
<?php $__env->startSection('content'); ?>
<div class="panel panel-primary">

    <div class="panel-heading">
        <div class="row">
            <div class="col-sm-8 text-left">
                <h3><?php echo e(trans('app.update_counter')); ?></h3>
            </div>
            <div class="col-sm-4 text-right">
                <button type="button" onclick="printContent('PrintMe')" class="btn btn-info" ><i class="fa fa-print"></i></button> 
            </div>
        </div>
    </div>

    <div class="panel-body">
        <?php echo e(Form::open(['url' => 'admin/counter/edit', 'class'=>'col-md-7 col-sm-8'])); ?>


            <input type="hidden" name="id" value="<?php echo e($counter->id); ?>">
     
            <div class="form-group <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label for="name"><?php echo e(trans('app.name')); ?> <i class="text-danger">*</i></label>
                <input type="text" name="name" id="name" class="form-control" placeholder="<?php echo e(trans('app.name')); ?>" value="<?php echo e(old('name')?old('name'):$counter->name); ?>">
                <span class="help-block text-danger"><?php echo e($errors->first('name')); ?></span>
            </div>

            <div class="form-group <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label for="description"><?php echo e(trans('app.description')); ?> </label> 
                <textarea name="description" id="description" class="form-control" placeholder="<?php echo e(trans('app.description')); ?>"><?php echo e(old('description')?old('description'):$counter->description); ?></textarea>
                <span class="help-block text-danger"><?php echo e($errors->first('description')); ?></span>
            </div>

            <div class="form-group <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label for="status"><?php echo e(trans('app.status')); ?> <i class="text-danger">*</i></label>
                <div id="status"> 
                    <label class="radio-inline">
                        <input type="radio" name="status" value="1" <?php echo e(((old('status') || $counter->status)==1)?"checked":""); ?>> <?php echo e(trans('app.active')); ?>

                    </label>
                    <label class="radio-inline">
                        <input type="radio" name="status" value="0" <?php echo e(((old('status') || $counter->status)==0)?"checked":""); ?>> <?php echo e(trans('app.deactive')); ?>

                    </label> 
                </div>
            </div>  

            <div class="form-group">
                <button class="button btn btn-info" type="reset"><span><?php echo e(trans('app.reset')); ?></span></button>
                <button class="button btn btn-success" type="submit"><span><?php echo e(trans('app.update')); ?></span></button> 
            </div>
        
        <?php echo e(Form::close()); ?> 
    </div> 
</div>  
<?php $__env->stopSection(); ?>


 


<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\main\resources\views/backend/admin/counter/edit.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title', trans('app.add_department')); ?>

<?php $__env->startSection('content'); ?>
<div class="panel panel-primary" id="printMe">
    <div class="panel-heading">
        <div class="row">
            <div class="col-sm-12 text-left">
                <h3><?php echo e(trans('app.add_department')); ?></h3>
            </div> 
        </div>
    </div>

    <div class="panel-body"> 

        <?php echo e(Form::open(['url' => 'admin/department/create', 'class'=>'col-md-7 col-sm-8'])); ?>


            <div class="form-group <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label for="name"><?php echo e(trans('app.name')); ?> <i class="text-danger">*</i></label> 
                <input type="text" name="name" id="name" class="form-control" placeholder="<?php echo e(trans('app.name')); ?>" value="<?php echo e(old('name')); ?>">
                <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
            </div>

            <div class="form-group <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label for="description"><?php echo e(trans('app.description')); ?> </label>  
                <textarea name="description" id="description" class="form-control" placeholder="<?php echo e(trans('app.description')); ?>"><?php echo e(old('description')); ?></textarea>
                <span class="text-danger"><?php echo e($errors->first('description')); ?></span> 
            </div>

            <div class="form-group <?php $__errorArgs = ['key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label for="key"><?php echo e(trans('app.key_for_keyboard_mode')); ?> <i class="text-danger">*</i></label><br/>
                <?php echo e(Form::select('key', $keyList, null, ['placeholder' => trans('app.select_option'), 'class'=>'select2 form-control'])); ?><br/>
                <span class="text-danger"><?php echo e($errors->first('key')); ?></span>
            </div>

            <div class="form-group <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label for="status"><?php echo e(trans('app.status')); ?> <i class="text-danger">*</i></label>
                <div id="status"> 
                    <label class="radio-inline">
                        <input type="radio" name="status" value="1" <?php echo e((old("status")==1)?"checked":""); ?>> <?php echo e(trans('app.active')); ?>

                    </label>
                    <label class="radio-inline">
                        <input type="radio" name="status" value="0" <?php echo e((old("status")==0)?"checked":""); ?>> <?php echo e(trans('app.deactive')); ?>

                    </label> 
                </div>
            </div>   

            <div class="form-group">
                <button class="button btn btn-info" type="reset"><span><?php echo e(trans('app.reset')); ?></span></button>
                <button class="button btn btn-success" type="submit"><span><?php echo e(trans('app.save')); ?></span></button>
            </div>
        <?php echo e(Form::close()); ?>

        
    </div>
</div> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\main\resources\views/backend/admin/department/form.blade.php ENDPATH**/ ?>
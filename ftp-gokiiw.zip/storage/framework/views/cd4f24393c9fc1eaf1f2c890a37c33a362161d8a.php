
<?php $__env->startSection('title', trans('app.sms_setting')); ?>
 
<?php $__env->startSection('content'); ?>
<div class="panel panel-primary">

    <div class="panel-heading">
        <div class="row">
            <div class="col-sm-12 text-left">
                <h3><?php echo e(trans('app.sms_setting')); ?></h3>
            </div> 
        </div>
    </div>

    <div class="panel-body"> 
        <?php echo Form::open(['url' => 'admin/sms/setting', 'class' => '']); ?>

        <div class="row">
            <div class="col-sm-6">
                <?php echo Form::hidden('id', $setting->id); ?>


                <div class="form-group <?php $__errorArgs = ['provider'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <label for="provider"><?php echo e(trans('app.provider')); ?><i class="text-danger">*</i></label><br/>
                    <?php echo e(Form::select('provider', ["nexmo"=>"Nexmo", "clickatell"=>"Click A Tell", "robi"=>"Robi","budgetsms"=>"Budget SMS", "campaigntag"=>"Campaign Tag"], (old('provider')?old('provider'):$setting->provider), ["id"=>"provider", "class"=>"select2 form-control"])); ?><br/>
                    <span class="text-danger"><?php echo e($errors->first('provider')); ?></span>
                </div>

                <div class="form-group <?php $__errorArgs = ['api_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <label for="api_key"><?php echo e(trans('app.api_key')); ?><i class="text-danger">*</i></label>
                    <input type="text" name="api_key" id="api_key" class="form-control" placeholder="<?php echo e(trans('app.api_key')); ?>" value="<?php echo e(old('api_key')?old('api_key'):$setting->api_key); ?>">
                    <span class="text-danger"><?php echo e($errors->first('api_key')); ?></span>
                </div>
                
                <div class="form-group <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <label for="username"><?php echo e(trans('app.username')); ?><i class="text-danger">*</i></label>
                    <input type="text" name="username" id="username" class="form-control" placeholder="<?php echo e(trans('app.username')); ?>" value="<?php echo e(old('username')?old('username'):$setting->username); ?>">
                    <span class="text-danger"><?php echo e($errors->first('username')); ?></span>
                </div>

                <div class="form-group <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <label for="password"><?php echo e(trans('app.password')); ?><i class="text-danger">*</i></label>
                    <input type="text" name="password" id="password" class="form-control" placeholder="<?php echo e(trans('app.password')); ?>" value="<?php echo e(old('password')?old('password'):$setting->password); ?>">
                    <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                </div>
                
                <div class="form-group <?php $__errorArgs = ['from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <label for="from"><?php echo e(trans('app.from')); ?><i class="text-danger">*</i></label>
                    <input type="text" name="from" id="from" class="form-control" placeholder="<?php echo e(trans('app.from')); ?>" value="<?php echo e(old('form')?old('form'):$setting->from); ?>">
                    <span class="text-danger"><?php echo e($errors->first('from')); ?></span>
                    <span class="text-info">(number for click-a-tell and any string for others)</span>
                </div>

                <div class="form-group">
                    <button class="button btn btn-info" type="reset"><span><?php echo e(trans('app.reset')); ?></span></button>
                    <button class="button btn btn-success" type="submit"><span><?php echo e(trans('app.update')); ?></span></button> 
                </div>
            </div>

            <div class="col-sm-6">
                <div class="well pb-0">
                    <strong>Available variable for SMS</strong>
                    <dl class="dl-horizontal">
                        <dt>[TOKEN]</dt><dd> - token no</dd>
                        <dt>[MOBILE]</dt><dd> - client mobile</dd>
                        <dt>[DEPARTMENT]</dt><dd> - department name</dd>
                        <dt>[COUNTER]</dt><dd> - counter name</dd>
                        <dt>[OFFICER]</dt><dd> - officer name</dd>
                        <dt>[WAIT]</dt><dd> - officer name</dd>
                        <dt>[DATE]</dt><dd> - date time</dd>
                    </dl>
                </div>

                <div class="form-group <?php $__errorArgs = ['sms_template'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <label for="sms_template"><?php echo e(trans('app.sms_template')); ?> <i class="text-danger">*</i></label>
                    <textarea name="sms_template" id="sms_template" class="form-control" placeholder="<?php echo e(trans('app.sms_template')); ?>" rows="3"><?php echo e(old('sms_template')?old('sms_template'):$setting->sms_template); ?></textarea>
                    <span class="text-danger"><?php echo e($errors->first('sms_template')); ?></span>
                </div>

                <div class="form-group <?php $__errorArgs = ['recall_sms_template'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <label for="recall_sms_template"><?php echo e(trans('app.recall_sms_template')); ?> <i class="text-danger">*</i></label>
                    <textarea name="recall_sms_template" id="recall_sms_template" class="form-control" placeholder="<?php echo e(trans('app.recall_sms_template')); ?>" rows="3"><?php echo e(old('recall_sms_template')?old('recall_sms_template'):$setting->recall_sms_template); ?></textarea>
                    <span class="text-danger"><?php echo e($errors->first('recall_sms_template')); ?></span>
                </div>    
            </div> 
        </div>
        <?php echo e(Form::close()); ?>

    </div>
</div>  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gigsoft.net/public_html/resources/views/backend/admin/sms/setting.blade.php ENDPATH**/ ?>
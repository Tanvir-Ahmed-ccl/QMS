<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login | Gokiiw</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  
  
    <style>
      .form-control{
        border: none;
        background: none;
        border-radius: 0;
        color: #fff;
      }
      .form-control::-webkit-input-placeholder { /* Chrome/Opera/Safari */
          color: #ffffff;
        }

      .form-control:focus{
        border-bottom: 1px solid white !important;
        background: none;
        border-radius: 0;
        color: #ffffff;
      }
    </style>
  </head>
  <body>

    <div class="row min-vh-100 p-0 m-0 align-items-center justify-content-center" style="background-color: #3498DB">
        
      <div class="col-lg-8">
          <a href="<?php echo e(url('/')); ?>">
            <h1 style="position: fixed; top:30px; left: 90px; color:#fff"><strong><?php echo e(env('APP_NAME')); ?></strong></h1>
          </a>          

          <div class="container" style="margin-top: 30px">
            <div class="row p-0 m-0 justify-content-center text-white">              

              <div class="col-md-8 p-4">

                <h1>Log In</h1>
                <h5>Don't have an account? <a href="<?php echo e(route('signup')); ?>" class="text-dark">Sign up here</a></h5>

                <?php if(isset($msg) && isset($email)): ?>
                <div class="row">
                  <span class="alert alert-danger">
                    <strong><?php echo e($msg); ?></strong>
                  </span>
                  <form action="<?php echo e(route('resendOtp')); ?>" method="post" id="resendOtpForm">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="email" value="<?php echo e($email); ?>">
                    <input type="hidden" name="password" value="<?php echo e($password); ?>">
                  </form>
                </div>
                <form action="<?php echo e(route('checkOtp')); ?>" method="POST" class="mt-5" id="checkOtpForm">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="email" value="<?php echo e($email); ?>">
                  <input type="hidden" name="password" value="<?php echo e($password); ?>">
                  
                  <div class="my-3">
                    <label for=""><strong>OTP</strong></label>
                    <input type="number" name="otp" required
                    autocomplete="off"
                    placeholder="XXXXXX" class="form-control border-bottom border-dark">                    
                  </div>

                  
                  
                </form>
                <div class="text-end">
                  <button class="btn btn-light text-primary fw-bolder me-2" 
                    onclick="document.getElementById('resendOtpForm').submit()">Resend OTP</button>
                  <button class="btn btn-light text-primary fw-bolder"
                    onclick="document.getElementById('checkOtpForm').submit()">LOG IN</button>
                </div>

                <?php else: ?>
                <form action="<?php echo e(route('sendOtp')); ?>" method="POST" class="mt-5">
                  <?php echo csrf_field(); ?>
                  <div class="my-3">
                    <label for=""><strong>Email</strong></label>
                    <input type="text" name="email" required
                    value="<?php echo e(old('email')); ?>"
                    autocomplete="off"
                    placeholder="john@example.com" class="form-control border-bottom border-dark">
                    

                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="text-danger">
                        <strong><?php echo e($message); ?></strong>
                      </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    
                  </div>

                  <div class="my-5">
                    <label for=""><strong>Password</strong></label>
                    <input type="password" name="password" required
                    value="<?php echo e(old('password')); ?>"
                    placeholder="Enter your Password" class="form-control border-bottom border-dark">

                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="text-danger">
                        <strong><?php echo e($message); ?></strong>
                      </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>

                  <?php if(session()->has('exception')): ?>
                    <div class="row">
                      <span class="alert alert-danger">
                        <strong><?php echo e(session('exception')); ?></strong>
                      </span>
                    </div>
                  <?php endif; ?>
                  
                  <div class="row">
                    <div class="col">
                      <a href="<?php echo e(route('password.request')); ?>" class="btn-link text-decoration-none text-white">Forgot your password?</a>
                    </div>
                    <div class="col text-end">
                      <button class="btn btn-light text-primary fw-bolder">LOG IN </button>
                    </div>
                  </div>
                </form>
                <?php endif; ?>
              </div>
            </div>
          </div>

        </div>
        <!--  .col-lg-7  -->

        <div class="col-lg-4 bg-white d-lg-block d-none">
            <div class="row min-vh-100 align-items-center p-3">
                <div class="col">
                  <h4>Hi I am John</h4>
                  <h6>I will be your personal guide to <?php echo e(env('APP_NAME')); ?>.</h6>

                  <img src="<?php echo e(asset('d/icon-526.png')); ?>" alt="" class="rounded-circle" width="200">
                
                  <h3 class="text-primary">John Doe</h3>
                  <h6>Head of Customer <br> Success at <?php echo e(env('APP_NAME')); ?></h6>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
  </body>
</html>
<?php /**PATH D:\CodeCell\ftp-gokiiw\resources\views/auth/login.blade.php ENDPATH**/ ?>
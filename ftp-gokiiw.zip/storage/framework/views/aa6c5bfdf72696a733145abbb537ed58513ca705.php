
<?php $__env->startSection('title', trans('app.performance_report')); ?>


<?php $__env->startSection('content'); ?>  
<div class="panel panel-primary">

    <div class="panel-heading">
        <div class="row">
            <div class="col-sm-12 text-left">
                <h3><?php echo e(trans('app.performance_report')); ?></h3>
            </div> 
        </div>
    </div> 

    <div class="panel-body"> 
        <?php echo e(Form::open(['url' => 'admin/token/performance', 'class' => 'form-inline mb-0', 'method' => 'get'])); ?>

        <table class="datatable display table table-bordered" width="100%" cellspacing="0">
            <thead>
                <tr>
                    <th rowspan="2">#</th>
                    <td>
                        <label><?php echo e(trans('app.start_date')); ?></label><br/>
                        <input type="text" name="start_date" value="<?php echo e($report->start_date); ?>" class="datepicker form-control input-sm" id="start_date" placeholder="<?php echo e(trans('app.start_date')); ?>" autocomplete="off" style="width:100px" />
                    </td> 
                    <td>
                        <label><?php echo e(trans('app.end_date')); ?></label><br/>
                        <input type="text" name="end_date" value="<?php echo e($report->end_date); ?>" class="datepicker form-control input-sm" id="end_date" placeholder="<?php echo e(trans('app.end_date')); ?>" autocomplete="off" style="width:100px" />
                    </td> 
                    <th colspan="3">
                        <button class="button btn btn-sm btn-success" type="submit"><?php echo e(trans('app.request')); ?></button>
                    </th>
                </tr> 
                <tr>
                    <th><?php echo e(trans('app.officer')); ?></th>
                    <th>Total</th>
                    <th>Stoped</th>
                    <th>Pending</th>
                    <th>Complete</th>
                </tr>  
            </thead> 
            <tbody>
                <?php 
                    $sl = 1; 
                    $grand_total   = 0;
                    $total_stoped  = 0;
                    $total_pending = 0;
                    $total_success = 0;
                ?>
                <?php if(!empty($tokens)): ?>
                    <?php $__currentLoopData = $tokens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $token): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($sl++); ?></td>
                            <td><a href='<?php echo e(url("admin/user/view/{$token->uid}")); ?>'><?php echo e($token->officer); ?></a></td>
                            <td><?php echo e($token->total); ?></td> 
                            <td><?php echo e($token->stoped); ?></td> 
                            <td><?php echo e($token->pending); ?></td>  
                            <td><?php echo e($token->success); ?></td>
                        </tr> 
                        <?php 
                            $grand_total   += $token->total;
                            $total_stoped  += $token->stoped;
                            $total_pending += $token->pending;
                            $total_success += $token->success;
                        ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>
            <tfoot> 
                <tr>
                    <th>#</th>
                    <th>
                        <strong><?php echo e(trans('app.start_date')); ?></strong> : <?php echo e((!empty($report->start_date)?date('j M Y h:i a',strtotime($report->start_date)):null)); ?>

                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <br/>
                        <strong><?php echo e(trans('app.end_date')); ?></strong>&nbsp; : <?php echo e((!empty($report->end_date)?date('j M Y h:i a',strtotime($report->end_date)):null)); ?><br/>
                    </th>
                    <th><?php echo e($grand_total); ?></th> 
                    <th><?php echo e($total_stoped); ?></th> 
                    <th><?php echo e($total_pending); ?></th>  
                    <th><?php echo e($total_success); ?></th>
                </tr>  
            </tfoot>
        </table> 
        <?php echo e(Form::close()); ?>

    </div> 
</div>  
<?php $__env->stopSection(); ?>
 

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gigsoft.net/public_html/resources/views/backend/admin/token/performance.blade.php ENDPATH**/ ?>
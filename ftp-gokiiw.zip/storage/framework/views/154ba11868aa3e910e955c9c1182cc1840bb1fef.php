
<?php $__env->startSection('title', trans('app.app_setting')); ?>

<?php $__env->startSection('content'); ?>
<div class="panel panel-primary" id="printMe">

    <div class="panel-heading">
        <div class="row">
            <div class="col-sm-12 text-left">
                <h3><?php echo e(trans('app.app_setting')); ?></h3>
            </div> 
        </div>
    </div>

    <div class="panel-body"> 

        <?php echo e(Form::open(['url' => 'admin/setting', 'files' => true, 'class'=>'col-md-7 col-sm-8'])); ?>


            <input type="hidden" name="id" value="<?php echo e($setting->id); ?>">
     
            <div class="form-group <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label for="title"><?php echo e(trans('app.title')); ?> <i class="text-danger">*</i></label> 
                <input type="text" name="title" id="title" class="form-control" placeholder="<?php echo e(trans('app.title')); ?>" value="<?php echo e(old('title')?old(
                'title'):$setting->title); ?>">
                <span class="text-danger"><?php echo e($errors->first('title')); ?></span>
            </div>

            <div class="form-group <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label for="description"><?php echo e(trans('app.description')); ?> </label>
                <textarea name="description" id="description" class="form-control" placeholder="<?php echo e(trans('app.description')); ?>"><?php echo e(old('description')?old(
                'description'):$setting->description); ?></textarea>
                <span class="text-danger"><?php echo e($errors->first('description')); ?></span>
            </div>

            <div class="form-group <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label for="email"><?php echo e(trans('app.email')); ?></label>
                <input type="text" name="email" id="email" class="form-control" placeholder="<?php echo e(trans('app.email')); ?>" value="<?php echo e(old('email')?old(
                'email'):$setting->email); ?>">
                <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
            </div>

            <div class="form-group <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label for="phone"><?php echo e(trans('app.mobile')); ?></label>
                <input type="text" name="phone" id="phone" class="form-control" placeholder="<?php echo e(trans('app.mobile')); ?>"  value="<?php echo e(old('phone')?old(
                'phone'):$setting->phone); ?>">
                <span class="text-danger"><?php echo e($errors->first('phone')); ?></span>
            </div>

            <div class="form-group <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label for="address"><?php echo e(trans('app.address')); ?> </label>
                <textarea name="address" id="address" class="form-control" placeholder="<?php echo e(trans('app.address')); ?>"><?php echo e(old('address')?old(
                'address'):$setting->address); ?></textarea>
                <span class="text-danger"><?php echo e($errors->first('address')); ?></span>
            </div>

            <div class="form-group <?php $__errorArgs = ['copyright_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label for="copyright_text"><?php echo e(trans('app.copyright')); ?> </label>
                <textarea name="copyright_text" id="copyright_text" class="form-control" placeholder="<?php echo e(trans('app.copyright')); ?>"><?php echo e(old('copyright_text')?old(
                'copyright_text'):$setting->copyright_text); ?></textarea>
                <span class="text-danger"><?php echo e($errors->first('copyright_text')); ?></span>
            </div>

            <div class="form-group <?php $__errorArgs = ['language'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <?php echo $__env->make('backend.common.info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <label for="lang-select"><?php echo e(trans('app.language')); ?> </label>
                <?php echo $__env->yieldContent('language'); ?>
                <span class="text-danger"><?php echo e($errors->first('language')); ?></span>
            </div> 

            <div class="form-group <?php $__errorArgs = ['timezone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label for="timezone"><?php echo e(trans('app.timezone')); ?> <i class="text-danger">*</i></label><br/>
                <?php echo e(Form::select('timezone', $timezoneList, (old('timezone')?old(
                                'timezone'):$setting->timezone) , [ 'class'=>'select2 form-control', "id"=>'timezone'])); ?><br/>
                <span class="text-danger"><?php echo e($errors->first('timezone')); ?></span>
            </div> 

            <div class="form-group <?php $__errorArgs = ['favicon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label for="favicon"><?php echo e(trans('app.favicon')); ?> </label>
                <img src="<?php echo e(asset((session('favicon')?session('favicon'):$setting->favicon))); ?>" alt="favicon" class="img-thubnail thumbnail" width="50" height="50"> 
                <input type="hidden" name="old_favicon" value="<?php echo e(((session('favicon') != null) ? session('favicon') : $setting->favicon)); ?>">  
                <input type="file" name="favicon" id="favicon" class="form-control">
                <span class="text-danger"><?php echo e($errors->first('favicon')); ?></span>
                <span class="help-block">Diamension: (32x32)px</span>
            </div>

            <div class="form-group <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label for="wlogo"><?php echo e(trans('app.logo')); ?></label>
                <img src="<?php echo e(asset($setting->logo)); ?>" alt="" class="img-thubnail thumbnail" width="200"> 
                <input type="hidden" name="old_logo" value="<?php echo e($setting->logo); ?>"> 
                <input type="file" name="logo" id="wlogo">
                <span class="text-danger"><?php echo e($errors->first('logo')); ?></span>
                <span class="help-block">Diamension: (250x50)px</span>
            </div>
     
            
            <div class="form-group">
                <button class="button btn btn-info" type="reset"><span><?php echo e(trans('app.reset')); ?></span></button>
                <button class="button btn btn-success" type="submit"><span><?php echo e(trans('app.update')); ?></span></button> 
            </div>
        
        <?php echo e(Form::close()); ?>


    </div>
</div> 
<?php $__env->stopSection(); ?>

 
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\main\resources\views/backend/admin/setting/setting.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title><?php echo e(\Session::get('app.title')); ?> :: <?php echo $__env->yieldContent('title'); ?></title>
        <!-- favicon -->
        <link rel="shortcut icon" href="<?php echo e(asset(Session::get('app.favicon'))); ?>" type="image/x-icon" />
        <!-- template bootstrap -->
        <link href="<?php echo e(asset('public/assets/css/template.min.css')); ?>" rel='stylesheet prefetch'>
        <!-- roboto -->
        <link href="<?php echo e(asset('public/assets/css/roboto.css')); ?>" rel='stylesheet'>
        <!-- material-design -->
        <link href="<?php echo e(asset('public/assets/css/material-design.css')); ?>" rel='stylesheet'>
        <!-- small-n-flat -->
        <link href="<?php echo e(asset('public/assets/css/small-n-flat.css')); ?>" rel='stylesheet'>
        <!-- font-awesome -->
        <link href="<?php echo e(asset('public/assets/css/font-awesome.min.css')); ?>" rel='stylesheet'>
        <!-- jquery-ui -->
        <link href="<?php echo e(asset('public/assets/css/jquery-ui.min.css')); ?>" rel='stylesheet'>
        <!-- datatable -->
        <link href="<?php echo e(asset('public/assets/css/dataTables.min.css')); ?>" rel='stylesheet'>
        <!-- select2 -->
        <link href="<?php echo e(asset('public/assets/css/select2.min.css')); ?>"  rel='stylesheet'>
        <!-- custom style -->
        <link href="<?php echo e(asset('public/assets/css/style.css')); ?>" rel='stylesheet'>
        <!-- Page styles --> 
        <?php echo $__env->yieldPushContent('styles'); ?>

        <!-- Jquery  -->
        <script src="<?php echo e(asset('public/assets/js/jquery.min.js')); ?>"></script>
    </head>
    <body class="cm-no-transition cm-1-navbar loader-process">
        <?php echo $__env->make('backend.common.info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="loader">
            <div>
                <span>G</span>
                <span>O</span>
                <span></span>
                <span>K</span>
                <span>I</span>
                <span>I</span>
                <span>W</span>
                
                
            </div>
        </div>

        <!-- Starts of Sidebar -->
        <div id="cm-menu">
            <nav class="cm-navbar cm-navbar-primary">
                <div class="cm-flex"><a href="javascript:void(0)">
                    <img src="<?php echo e(asset(\Session::get('app.logo'))); ?>" width="210" height="50">
                </a></div>
                <div class="btn btn-primary md-menu-white" data-toggle="cm-menu"></div>
            </nav>
            <div id="cm-menu-content">
                <div id="cm-menu-items-wrapper">
                    <div id="cm-menu-scroller">
                        <ul class="cm-menu-items">
                            <!-- // ADMIN MENU -->
                            <?php if(Auth::user()->hasRole('admin')): ?> 
                            <li class="<?php echo e(((Request::is('admin')) ? 'active' : '')); ?>">
                                <a href="<?php echo e(url('admin')); ?>" class="sf-dashboard">
                                    <?php echo e(trans('app.dashboard')); ?>

                                </a>
                            </li>

                            <li class="cm-submenu <?php echo e((Request::segment(2)=='department' ? 'open' : '')); ?>">
                                <a class="sf-carton"><?php echo e(trans('app.department')); ?> <span class="caret"></span></a>
                                <ul>
                                    <li class="<?php echo e((Request::is('admin/department/create') ? 'active' : '')); ?>">
                                        <a href="<?php echo e(url('admin/department/create')); ?>"><?php echo e(trans('app.add_department')); ?></a>
                                    </li>
                                    <li class="<?php echo e((Request::is('admin/department') ? 'active' : '')); ?>">
                                        <a href="<?php echo e(url('admin/department')); ?>"><?php echo e(trans('app.department_list')); ?></a>
                                    </li>
                                </ul>
                            </li> 

                            <li class="cm-submenu <?php echo e((Request::segment(2)=='counter' ? 'open' : '')); ?>">
                                <a class="sf-star"><?php echo e(trans('app.counter')); ?> <span class="caret"></span></a>
                                <ul>
                                    <li class="<?php echo e((Request::is('admin/counter/create') ? 'active' : '')); ?>">
                                        <a href="<?php echo e(url('admin/counter/create')); ?>"><?php echo e(trans('app.add_counter')); ?></a>
                                    </li>
                                    <li class="<?php echo e((Request::is('admin/counter') ? 'active' : '')); ?>">
                                        <a href="<?php echo e(url('admin/counter')); ?>"><?php echo e(trans('app.counter_list')); ?></a>
                                    </li>
                                </ul>
                            </li> 

                            <li class="cm-submenu <?php echo e((Request::segment(2)=='user' ? 'open' : '')); ?>">
                                <a class="sf-profile-group"><?php echo e(trans('app.users')); ?> <span class="caret"></span></a>
                                <ul>
                                    <li class="<?php echo e((Request::is('admin/user/create') ? 'active' : '')); ?>">
                                        <a href="<?php echo e(url('admin/user/create')); ?>"><?php echo e(trans('app.add_user')); ?></a>
                                    </li>
                                    <li class="<?php echo e((Request::is('admin/user') ? 'active' : '')); ?>">
                                        <a href="<?php echo e(url('admin/user')); ?>"><?php echo e(trans('app.user_list')); ?></a>
                                    </li>
                                </ul>
                            </li> 

                            <li class="cm-submenu <?php echo e((Request::segment(2)=='sms' ? 'open' : '')); ?>">
                                <a class="sf-bubbles"><?php echo e(trans('app.sms')); ?> <span class="caret"></span></a>
                                <ul>
                                    <li class="<?php echo e((Request::is('admin/sms/new') ? 'active' : '')); ?>">
                                        <a href="<?php echo e(url('admin/sms/new')); ?>"><?php echo e(trans('app.new_sms')); ?></a>
                                    </li>
                                    <li class="<?php echo e((Request::is('admin/sms/list') ? 'active' : '')); ?>">
                                        <a href="<?php echo e(url('admin/sms/list')); ?>"><?php echo e(trans('app.sms_history')); ?></a>
                                    </li>
                                    <li class="bg-danger <?php echo e((Request::is('admin/sms/setting') ? 'active' : '')); ?>">
                                        <a href="<?php echo e(url('admin/sms/setting')); ?>"><?php echo e(trans('app.sms_setting')); ?></a>
                                    </li>
                                </ul>
                            </li> 

                            <li class="cm-submenu <?php echo e((Request::segment(2)=='token' ? 'open' : '')); ?>">
                                <a class="sf-user-id"><?php echo e(trans('app.token')); ?> <span class="caret"></span></a>
                                <ul>
                                    <li class="<?php echo e((Request::is('admin/token/list') ? 'active' : '')); ?>">
                                        <a href="<?php echo e(url('admin/token/auto')); ?>"><?php echo e(trans('app.auto_token')); ?></a>
                                    </li>
                                    <li class="<?php echo e((Request::is('admin/token/create') ? 'active' : '')); ?>">
                                        <a href="<?php echo e(url('admin/token/create')); ?>"><?php echo e(trans('app.manual_token')); ?></a>
                                    </li>
                                    <li class="<?php echo e((Request::is('admin/token/current') ? 'active' : '')); ?>">
                                        <a href="<?php echo e(url('admin/token/current')); ?>"><?php echo e(trans('app.active')); ?> / <?php echo e(trans('app.todays_token')); ?> <i class="fa fa-dot-circle-o" style="color:#03d003"></i></a>
                                    </li> 
                                    <li class="<?php echo e((Request::is('admin/token/report') ? 'active' : '')); ?>">
                                        <a href="<?php echo e(url('admin/token/report')); ?>"><?php echo e(trans('app.token_report')); ?></a>
                                    </li> 
                                    <li class="<?php echo e((Request::is('admin/token/performance') ? 'active' : '')); ?>">
                                        <a href="<?php echo e(url('admin/token/performance')); ?>"><?php echo e(trans('app.performance_report')); ?></a>
                                    </li> 
                                    <li class="bg-danger <?php echo e((Request::is('admin/token/setting') ? 'active' : '')); ?>">
                                        <a href="<?php echo e(url('admin/token/setting')); ?>"><?php echo e(trans('app.auto_token_setting')); ?></a>
                                    </li>
                                </ul>
                            </li>  
                            <?php endif; ?>

                            <!-------------------------------------------------------->
                            <!-- OFFICER MENU                                       -->
                            <!-------------------------------------------------------->
                            <?php if(Auth::user()->hasRole('officer')): ?>  
                            <li class="<?php echo e(((Request::is('officer')) ? 'active' : '')); ?>">
                                <a href="<?php echo e(url('officer')); ?>" class="sf-dashboard">
                                    <?php echo e(trans('app.dashboard')); ?> 
                                </a>
                            </li>
 

                            <li class="cm-submenu <?php echo e((Request::segment(2)=='token' ? 'open' : '')); ?>">
                                <a class="sf-user-id"><?php echo e(trans('app.token')); ?> <span class="caret"></span></a>
                                <ul> 
                                    <li class="<?php echo e((Request::is('officer/token/current') ? 'active' : '')); ?>">
                                        <a href="<?php echo e(url('officer/token/current')); ?>"><?php echo e(trans('app.active')); ?> / <?php echo e(trans('app.todays_token')); ?> <i class="fa fa-dot-circle-o" style="color:#03d003"></i></a>
                                    </li>
                                    <li class="<?php echo e((Request::is('officer/token') ? 'active' : '')); ?>">
                                        <a href="<?php echo e(url('officer/token')); ?>"><?php echo e(trans('app.token_list')); ?></a>
                                    </li> 
                                </ul>
                            </li>  
                            <?php endif; ?>

                            <!-------------------------------------------------------->
                            <!-- RECEPTIONIST MENU                               -->
                            <!-------------------------------------------------------->
                            <?php if(Auth::user()->hasRole('receptionist')): ?>  
                            <li class="cm-submenu <?php echo e(((Request::is('receptionist') || Request::segment(2)=='token') ? 'open' : '')); ?>">
                                <a class="sf-user-id"><?php echo e(trans('app.token')); ?> <span class="caret"></span></a>
                                <ul>
                                    <li class="<?php echo e((Request::is('receptionist/token/list') ? 'active' : '')); ?>">
                                        <a href="<?php echo e(url('receptionist/token/auto')); ?>"><?php echo e(trans('app.auto_token')); ?></a>
                                    </li>
                                    <li class="<?php echo e((Request::is('receptionist/token/create') ? 'active' : '')); ?>">
                                        <a href="<?php echo e(url('receptionist/token/create')); ?>"><?php echo e(trans('app.manual_token')); ?></a>
                                    </li>
                                    <li class="<?php echo e((Request::is('receptionist/token/current') ? 'active' : '')); ?>">
                                        <a href="<?php echo e(url('receptionist/token/current')); ?>"><?php echo e(trans('app.active')); ?> / <?php echo e(trans('app.todays_token')); ?> <i class="fa fa-dot-circle-o" style="color:#03d003"></i></a>
                                    </li> 
                                </ul>
                            </li> 
                            <?php endif; ?>

 
                            <!-------------------------------------------------------->
                            <!-- COMMON MENU                                        -->
                            <!-------------------------------------------------------->

                            <li class="cm-submenu <?php echo e((Request::segment(2)=='display' ? 'open' : '')); ?>">
                                <a target="_blank" class="sf-device-tablet">
                                    <?php echo e(trans('app.display')); ?> 
                                    <span class="caret"></span>
                                </a>
                                <ul>
                                    <li class="<?php echo e((session()->get('app.display')==1 ? 'active' : '')); ?>">
                                        <a href="<?php echo e(url('common/display?type=1')); ?>" target="_blank"><?php echo e(trans('app.display_1')); ?></a>
                                    </li> 
                                    <li class="<?php echo e((session()->get('app.display')==2 ? 'active' : '')); ?>">
                                        <a href="<?php echo e(url('common/display?type=2')); ?>" target="_blank"><?php echo e(trans('app.display_2')); ?></a>
                                    </li> 
                                    <li class="<?php echo e((session()->get('app.display')==3 ? 'active' : '')); ?>">
                                        <a href="<?php echo e(url('common/display?type=3')); ?>" target="_blank"><?php echo e(trans('app.display_3')); ?></a>
                                    </li> 
                                    <li class="<?php echo e((session()->get('app.display')==4 ? 'active' : '')); ?>">
                                        <a href="<?php echo e(url('common/display?type=4')); ?>" target="_blank"><?php echo e(trans('app.display_4')); ?></a>
                                    </li> 
                                    <li class="<?php echo e((session()->get('app.display')==5 ? 'active' : '')); ?>">
                                        <a href="<?php echo e(url('common/display?type=5')); ?>" target="_blank"><?php echo e(trans('app.display_5')); ?></a>
                                    </li>   

                                    <?php if(session()->has('custom_displays')): ?>
                                    <?php $__currentLoopData = session()->get('custom_displays'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="<?php echo e(url('common/display?type=6&custom='.$key)); ?>" target="_blank"><?php echo e(trans('app.custom_display')); ?> - <?php echo e($name); ?></a>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?> 
                                </ul>
                            </li> 

                            <li class="cm-submenu <?php echo e((Request::segment(2)=='message' ? 'open' : '')); ?>">
                                <a class="sf-envelope-letter"><?php echo e(trans('app.message')); ?> <span class="caret"></span></a>
                                <ul>
                                    <li class="<?php echo e((Request::is('common/message') ? 'active' : '')); ?>">
                                        <a href="<?php echo e(url('common/message')); ?>"><?php echo e(trans('app.new_message')); ?></a>
                                    </li>
                                    <li class="<?php echo e((Request::is('common/message/inbox') ? 'active' : '')); ?>">
                                        <a href="<?php echo e(url('common/message/inbox')); ?>"><?php echo e(trans('app.inbox')); ?></a>
                                    </li>
                                    <li class="<?php echo e((Request::is('common/message/sent') ? 'active' : '')); ?>">
                                        <a href="<?php echo e(url('common/message/sent')); ?>"><?php echo e(trans('app.sent')); ?></a>
                                    </li>
                                </ul>
                            </li> 

                            <li class="cm-submenu <?php echo e((Request::segment(2)=='setting' ? 'open' : '')); ?>">
                                <a class="sf-cog"><?php echo e(trans('app.setting')); ?> <span class="caret"></span></a>
                                <ul>
                                    <?php if(auth()->user()->hasRole('admin')): ?>
                                    <li class="<?php echo e((Request::is('admin/setting') ? 'active' : '')); ?>">
                                        <a href="<?php echo e(url('admin/setting')); ?>"><?php echo e(trans('app.app_setting')); ?></a>
                                    </li>
                                    <li class="<?php echo e((Request::is('admin/setting/display') ? 'active' : '')); ?>">
                                        <a href="<?php echo e(url('admin/setting/display')); ?>"><?php echo e(trans('app.display_setting')); ?></a>
                                    </li>
                                    <?php endif; ?>

                                    <li class="<?php echo e((Request::is('common/setting/*') ? 'active' : '')); ?>">
                                        <a href="<?php echo e(url('common/setting/profile')); ?>"><?php echo e(trans('app.profile_information')); ?></a>
                                    </li>
                                </ul>
                            </li> 

                            <li class="<?php echo e(((Request::is('logout')) ? 'active' : '')); ?>">
                                <a href="<?php echo e(url('logout')); ?>" class="sf-lock">
                                    <?php echo e(trans('app.signout')); ?>

                                </a>
                            </li> 
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- Ends of Sidebar -->


        <!-- Starts of Header/Menu --> 
        <header id="cm-header">
            <nav class="cm-navbar cm-navbar-primary">
                <div class="btn btn-primary md-menu-white hidden-md hidden-lg" data-toggle="cm-menu"></div>
                <div class="cm-flex">
                    <h1 class="clearfix"><?php echo e(\Session::get('app.title')); ?></h1> 
                </div> 

                <!-- Buy Now -->
                <?php echo $__env->yieldContent('info.buy-now'); ?>

                <div class="dropdown pull-right">
                    <button class="btn btn-primary md-desktop-windows-white" data-toggle="dropdown"></button>
                    <div class="popover cm-popover bottom">
                        <div class="arrow"></div>
                        <div class="popover-content">
                            <div class="list-group"> 
                                <a href="<?php echo e(url('common/display?type=1')); ?>" target="_blank" class="<?php echo e(session()->get('app.display')==1?'active':null); ?> list-group-item">
                                    <h4 class="list-group-item-heading"></i> <?php echo e(trans('app.display_1')); ?></h4>
                                </a>
                                <a href="<?php echo e(url('common/display?type=2')); ?>" target="_blank" class="<?php echo e(session()->get('app.display')==2?'active':null); ?> list-group-item">
                                    <h4 class="list-group-item-heading"></i> <?php echo e(trans('app.display_2')); ?></h4>
                                </a>
                                <a href="<?php echo e(url('common/display?type=3')); ?>" target="_blank" class="<?php echo e(session()->get('app.display')==3?'active':null); ?> list-group-item">
                                    <h4 class="list-group-item-heading"></i> <?php echo e(trans('app.display_3')); ?></h4>
                                </a>
                                <a href="<?php echo e(url('common/display?type=4')); ?>" target="_blank" class="<?php echo e(session()->get('app.display')==4?'active':null); ?> list-group-item">
                                    <h4 class="list-group-item-heading"></i> <?php echo e(trans('app.display_4')); ?></h4>
                                </a>
                                <a href="<?php echo e(url('common/display?type=5')); ?>" target="_blank" class="<?php echo e(session()->get('app.display')==5?'active':null); ?> list-group-item">
                                    <h4 class="list-group-item-heading"></i> <?php echo e(trans('app.display_5')); ?></h4>
                                </a>
                                <?php if(session()->has('custom_displays')): ?>
                                <?php $__currentLoopData = session()->get('custom_displays'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(url('common/display?type=6&custom='.$key)); ?>" target="_blank" class="list-group-item">
                                    <h4 class="list-group-item-heading"></i> <?php echo e(trans('app.custom_display')); ?> - <?php echo e($name); ?></h4>
                                </a> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?> 
                            </div>
                        </div>
                    </div>
                </div> 

                <div class="dropdown pull-right">
                    <a href="<?php echo e(url('common/message/inbox')); ?>" class="btn btn-primary md-local-post-office-white"> <span class="label label-danger" id="message-notify">0</span> </a> 
                </div>
                <div class="dropdown pull-right">
                    <button class="btn btn-primary md-language-white" data-toggle="dropdown"> <span class="label label-danger"><?php echo e(Session::get('locale')? Session::get('locale'):'en'); ?></span></button>
                    <div class="popover cm-popover bottom">
                        <div class="arrow"></div>
                        <div class="popover-content">
                            <div class="list-group"> 
                                <a href="javascript:void(0)" data-locale="en" class="select-lang list-group-item <?php echo e(((Session::get('locale')=='en' || !Session::has('locale'))?'active':'')); ?>">
                                    <h4 class="list-group-item-heading"></i> English</h4>
                                </a>
                                <a href="javascript:void(0)" data-locale="ar" class="select-lang list-group-item <?php echo e((Session::get('locale')=='ar'?'active':'')); ?>">
                                    <h4 class="list-group-item-heading"></i> العَرَبِيَّة'</h4>
                                </a> 
                                <a href="javascript:void(0)" data-locale="tr" class="select-lang list-group-item <?php echo e((Session::get('locale')=='tr'?'active':'')); ?>">
                                    <h4 class="list-group-item-heading"></i> Türkçe</h4>
                                </a> 
                                <a href="javascript:void(0)" data-locale="bn" class="select-lang list-group-item <?php echo e((Session::get('locale')=='bn'?'active':'')); ?>">
                                    <h4 class="list-group-item-heading"></i> বাংলা</h4>
                                </a> 
                                <a href="javascript:void(0)" data-locale="es" class="select-lang list-group-item <?php echo e((Session::get('locale')=='es'?'active':'')); ?>">
                                    <h4 class="list-group-item-heading"></i> Español</h4>
                                </a> 
                                <a href="javascript:void(0)" data-locale="fr" class="select-lang list-group-item <?php echo e((Session::get('locale')=='fr'?'active':'')); ?>">
                                    <h4 class="list-group-item-heading"></i> Français</h4>
                                </a> 
                                <a href="javascript:void(0)" data-locale="pt" class="select-lang list-group-item <?php echo e((Session::get('locale')=='pt'?'active':'')); ?>">
                                    <h4 class="list-group-item-heading"></i> Português</h4>
                                </a> 
                                <a href="javascript:void(0)" data-locale="te" class="select-lang list-group-item <?php echo e((Session::get('locale')=='te'?'active':'')); ?>">
                                    <h4 class="list-group-item-heading"></i> తెలుగు</h4>
                                </a> 
                                <a href="javascript:void(0)" data-locale="th" class="select-lang list-group-item <?php echo e((Session::get('locale')=='th'?'active':'')); ?>">
                                    <h4 class="list-group-item-heading"></i> ภาษาไทย</h4>
                                </a> 
                                <a href="javascript:void(0)" data-locale="vi" class="select-lang list-group-item <?php echo e(((Session::get('locale')=='vi')?'active':'')); ?>">
                                    <h4 class="list-group-item-heading"></i> Tiếng Việt</h4>
                                </a>
                            </div>
                        </div>
                    </div>
                </div> 
                <?php if($user = Auth::user()): ?> 
                <div class="dropdown pull-right">
                    <button class="btn btn-primary md-account-circle-white" data-toggle="dropdown"></button>
                    <ul class="dropdown-menu">
                        <li class="disabled text-center">
                            <img src="<?php echo e(!empty($user->photo)?asset($user->photo):asset('public/assets/img/icons/no_user.jpg')); ?>" width="140" height="105">
                        </li>
                        <li class="disabled text-center">
                            <a style="cursor:default;"><strong><?php echo e($user->firstname .' '. $user->lastname); ?></strong> 
                            </a>
                            <span class="label label-success"><?php echo e(auth()->user()->role()); ?></span>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="<?php echo e(url('common/setting/profile')); ?>"><i class="fa fa-user"></i> <?php echo e(trans('app.profile_information')); ?></a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('logout')); ?>"><i class="fa fa-sign-out"></i> <?php echo e(trans('app.signout')); ?></a>
                        </li>
                    </ul>
                </div>
                <?php endif; ?>
            </nav>
        </header>
        <!-- Ends of Header/Menu -->


        <div id="global"> 

            <div class="container-fluid"> 
                <!-- Starts of Message -->
                <?php echo $__env->yieldContent('info.message'); ?>
                <!-- Ends of Message --> 

                <!-- Starts of Content -->
                <?php echo $__env->yieldContent('content'); ?>
                <!-- Ends of Contents --> 
            </div>

            <!-- Starts of Copyright -->
                
            <footer class="cm-footer text-right">
                <span class="hidden-xs"><?php echo e(\Session::get('app.copyright_text')); ?></span>
                
                <span class="pull-left text-center">Powered By Gokiiw</span> 
            </footer>
            <!-- Ends of Copyright -->
        </div>


        <!-- All js -->
        <!-- bootstrp -->
        <script src="<?php echo e(asset('public/assets/js/bootstrap.min.js')); ?>"></script> 
        <!-- select2 -->
        <script src="<?php echo e(asset('public/assets/js/select2.min.js')); ?>"></script>
        <!-- juery-ui -->
        <script src="<?php echo e(asset('public/assets/js/jquery-ui.min.js')); ?>"></script> 
        <!-- jquery.mousewheel.min -->
        <script src="<?php echo e(asset('public/assets/js/jquery.mousewheel.min.js')); ?>"></script>
        <!-- jquery.cookie.min -->
        <script src="<?php echo e(asset('public/assets/js/jquery.cookie.min.js')); ?>"></script>
        <!-- fastclick -->
        <script src="<?php echo e(asset('public/assets/js/fastclick.min.js')); ?>"></script>
        <!-- template -->
        <script src="<?php echo e(asset('public/assets/js/template.js')); ?>"></script>
        <!-- datatable -->
        <script src="<?php echo e(asset('public/assets/js/dataTables.min.js')); ?>"></script>
        <!-- custom script -->
        <script src="<?php echo e(asset('public/assets/js/script.js')); ?>"></script>
        
        <!-- Page Script -->
        <?php echo $__env->yieldPushContent('scripts'); ?>
        
        <script type="text/javascript">
        (function() {
          //notification
            notify();
            setInterval(function(){
                notify();
            }, 30000);

            function notify()
            {
                $.ajax({
                   type:'GET',
                   url:'<?php echo e(URL::to("common/message/notify")); ?>',
                   data:'_token = <?php echo csrf_token() ?>',
                   success:function(data){
                      $("#message-notify").html(data);
                   }
                });
            }
         
            //language switch
            $(".select-lang").on('click', function() { 
                $.ajax({
                   type:'GET',
                   url: '<?php echo e(url("common/language")); ?>',
                   data: {
                      'locale' : $(this).data("locale"), 
                      '_token' : '<?php echo csrf_token() ?>'
                   },
                   success:function(data){
                      history.go(0);
                   }, error: function() {
                    alert('failed');
                   }
                });       
            });
            
        })();
        </script>
    </body>
</html>

 <?php /**PATH /home/gigsoft.net/public_html/resources/views/layouts/backend.blade.php ENDPATH**/ ?>
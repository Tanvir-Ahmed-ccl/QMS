<?php $__env->startComponent('mail::message'); ?>
## Hello!

Your two factor authenticaion code is given below -

<?php $__env->startComponent('mail::panel'); ?>
<span style="text-align: center; display:block; font-size: 22px; margin: 0; font-weight:bolder"><?php echo e($otp); ?></span>
<?php if (isset($__componentOriginal78a7183c9f5e577b074162f44312b5a9c6fd7b4c)): ?>
<?php $component = $__componentOriginal78a7183c9f5e577b074162f44312b5a9c6fd7b4c; ?>
<?php unset($__componentOriginal78a7183c9f5e577b074162f44312b5a9c6fd7b4c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

The code will expire in 10 minutes.

If you have not tried to login, ignore this message.

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\CodeCell\ftp-gokiiw\resources\views/mail/otp-email.blade.php ENDPATH**/ ?>
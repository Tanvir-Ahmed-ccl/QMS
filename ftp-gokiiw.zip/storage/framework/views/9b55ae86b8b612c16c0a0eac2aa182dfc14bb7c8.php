
<?php $__env->startSection('title', trans('app.update_user')); ?>

<?php $__env->startSection('content'); ?>
<div class="panel panel-primary">

    <div class="panel-heading">
        <div class="row">
            <div class="col-sm-12 text-left">
                <h3><?php echo e(trans('app.update_user')); ?></h3>
            </div> 
        </div>
    </div>

    <div class="panel-body"> 
        <?php echo e(Form::open(['url' => 'common/setting/profile/edit', 'files' => true, 'class'=>'col-md-7 col-sm-8'])); ?>


             <div class="form-group <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label for="firstname"><?php echo e(trans('app.firstname')); ?> <i class="text-danger">*</i></label> 
                <input type="text" name="firstname" id="firstname" class="form-control" placeholder="<?php echo e(trans('app.firstname')); ?>" value="<?php echo e(old('firstname')?old('firstname'):$user->firstname); ?>">
                <span class="text-danger"><?php echo e($errors->first('firstname')); ?></span>
            </div>

            <div class="form-group <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label for="lastname"><?php echo e(trans('app.lastname')); ?> <i class="text-danger">*</i></label> 
                <input type="text" name="lastname" id="lastname" class="form-control" placeholder="<?php echo e(trans('app.lastname')); ?>" value="<?php echo e(old('lastname')?old('lastname'):$user->lastname); ?>">
                <span class="text-danger"><?php echo e($errors->first('lastname')); ?></span>
            </div>

            <div class="form-group <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label for="email"><?php echo e(trans('app.email')); ?> <i class="text-danger">*</i></label> 
                <input type="text" name="email" id="email" class="form-control" placeholder="<?php echo e(trans('app.email')); ?>" value="<?php echo e(old('email')?old('email'):$user->email); ?>">
                <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
            </div>

            <div class="form-group <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label for="password"><?php echo e(trans('app.password')); ?> <i class="text-danger">*</i></label> 
                <input type="password" name="password" id="password" class="form-control" placeholder="<?php echo e(trans('app.password')); ?>" value="<?php echo e(old('password')); ?>">
                <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
            </div>

            <div class="form-group <?php $__errorArgs = ['conf_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label for="conf_password"><?php echo e(trans('app.conf_password')); ?> <i class="text-danger">*</i></label> 
                <input type="password" name="conf_password" id="conf_password" class="form-control" placeholder="<?php echo e(trans('app.conf_password')); ?>" value="<?php echo e(old('conf_password')); ?>">
                <span class="text-danger"><?php echo e($errors->first('conf_password')); ?></span>
            </div>

            <div class="form-group <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label for="mobile"><?php echo e(trans('app.mobile')); ?> <i class="text-danger">*</i></label> 
                <input type="text" name="mobile" id="mobile" class="form-control" placeholder="<?php echo e(trans('app.mobile')); ?>" value="<?php echo e(old('mobile')?old('mobile'):$user->mobile); ?>">
                <span class="text-danger"><?php echo e($errors->first('mobile')); ?></span>
            </div>

            <div class="row">
                <div class="col-sm-4">
                    <img src="<?php echo e(asset((session('photo')?session('photo'):$user->photo))); ?>" alt="Photo" class="img-thubnail thumbnail" width="140" height="100">
                    <input type="file" name="photo" id="photo">  
                    <input type="hidden" name="old_photo" value="<?php echo e(((session('photo') != null) ? session('photo') : $user->photo)); ?>"> 
                </div> 

                <div class="col-sm-4"></div> 

                <div class="col-sm-4">
                    <div class="form-group">
                        <button class="button btn btn-info" type="reset"><span><?php echo e(trans('app.reset')); ?></span></button>
                        <button class="button btn btn-success" type="submit"><span><?php echo e(trans('app.update')); ?></span></button> 
                    </div>
                </div>
            </div>

        <?php echo e(Form::close()); ?>

    </div>
</div> 
<?php $__env->stopSection(); ?>


 

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gigsoft.net/public_html/resources/views/backend/common/setting/profile_edit.blade.php ENDPATH**/ ?>
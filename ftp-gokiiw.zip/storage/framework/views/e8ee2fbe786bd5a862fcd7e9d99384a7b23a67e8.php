
<?php $__env->startSection('title', trans('app.user_information')); ?>

<?php $__env->startSection('content'); ?>
<div class="panel panel-primary">
    <div class="panel-heading">
        <div class="row">
            <div class="col-sm-8 text-left">
                <h3><?php echo e(trans('app.user_information')); ?></h3>
            </div>
            <div class="col-sm-4 text-right">
                <div class="btn-group">
                    <?php if($user->user_type != 5): ?>
                    <a href=" <?php echo e(url("admin/user/edit/$user->id")); ?>"  class="btn btn-sm btn-success" ><i class="fa fa-edit"></i></a> 
                    <?php endif; ?>
                    <button type="button" onclick="printThis('printThis')" class="btn btn-sm btn-info" ><i class="fa fa-print"></i></button> 
                </div>
            </div>
        </div>
    </div>

    <div class="panel-body" id="printThis"> 
        <div class="row"> 
            <div class="col-sm-3" align="center"> 
                <img alt="Picture" src="<?php echo e(asset((!empty($user->photo)?$user->photo:'public/assets/img/icons/no_user.jpg'))); ?>" class="img-thumbnail img-responsive">
                <h3>
                    <?php echo e($user->firstname .' '. $user->lastname); ?>

                </h3>
                <span class="label label-info"><?php echo e(auth()->user()->roles($user->user_type)); ?></span> 

            </div> 

            <div class="col-sm-9"> 
                <dl class="dl-horizontal">
                    <dt><?php echo e(trans('app.department')); ?></dt><dd><?php echo e(($user->department?$user->department:"N/A")); ?></dd>
                    <dt><?php echo e(trans('app.email')); ?></dt><dd><?php echo e($user->email); ?></dd>
                    <dt><?php echo e(trans('app.mobile')); ?></dt><dd><?php echo e($user->mobile); ?></dd>
                    <dt><?php echo e(trans('app.created_at')); ?></dt><dd><?php echo e((!empty($user->created_at)?date('j M Y h:i a',strtotime($user->created_at)):null)); ?></dd>
                    <dt><?php echo e(trans('app.updated_at')); ?></dt><dd><?php echo e((!empty($user->updated_at)?date('j M Y h:i a',strtotime($user->updated_at)):null)); ?></dd>
                    <dt><?php echo e(trans('app.status')); ?></dt>
                    <dd>
                        <?php if($user->status==1): ?>
                        <span class="label label-success"><?php echo e(trans('app.active')); ?></span>
                        <?php else: ?>
                        <span class="label label-danger"><?php echo e(trans('app.deactive')); ?></span>
                        <?php endif; ?>
                    </dd>
                </dl> 
            </div>
        </div>  

        <div class="row">
            <div class="col-sm-12 panel-body table-responsive">
                <table class="table table-bordered text-center">
                    <thead>
                        <tr class="active">
                            <th><?php echo e(trans('app.status')); ?></th>
                            <td><?php echo e(trans('app.my_token')); ?></td>
                            <td><?php echo e(trans('app.generated_by_me')); ?></td>
                            <td><?php echo e(trans('app.assigned_to_me')); ?></td>
                            <td><?php echo e(trans('app.total')); ?></td>
                        </tr>
                    </thead> 
                    <tbody>
                        <tr>
                            <th scope="row" class="active"><?php echo e(trans('app.pending')); ?></th>
                            <td class="info"><?php echo e(!empty($myToken['0'])?$myToken['0']:0); ?></td> 
                            <td class="info"><?php echo e(!empty($myToken['1'])?$myToken['1']:0); ?></td> 
                            <td class="info"><?php echo e(!empty($myToken['2'])?$myToken['2']:0); ?></td> 
                            <td class="active"><?php echo e(@$myToken['0']+@$myToken['1']+@$myToken['2']); ?></td> 
                        </tr> 
                        <tr>
                            <th scope="row" class="active"><?php echo e(trans('app.complete')); ?></th> 
                            <td class="success"><?php echo e(!empty($generatedByMe['0'])?$generatedByMe['0']:0); ?></td> 
                            <td class="success"><?php echo e(!empty($generatedByMe['1'])?$generatedByMe['1']:0); ?></td> 
                            <td class="success"><?php echo e(!empty($generatedByMe['2'])?$generatedByMe['2']:0); ?></td> 
                            <td class="active"><?php echo e(@$generatedByMe['0']+@$generatedByMe['1']+@$generatedByMe['2']); ?></td> 
                        </tr> 
                        <tr>
                            <th scope="row" class="active"><?php echo e(trans('app.stop')); ?></th> 
                            <td class="danger"><?php echo e(!empty($assignedToMe['0'])?$assignedToMe['0']:0); ?></td> 
                            <td class="danger"><?php echo e(!empty($assignedToMe['1'])?$assignedToMe['1']:0); ?></td> 
                            <td class="danger"><?php echo e(!empty($assignedToMe['2'])?$assignedToMe['2']:0); ?></td> 
                            <td class="active"><?php echo e(@$assignedToMe['0']+@$assignedToMe['1']+@$assignedToMe['2']); ?></td> 
                        </tr> 
                    </tbody>
                    <thead>
                        <tr class="active">
                            <th><?php echo e(trans('app.total')); ?></th>
                            <td><?php echo e(@$myToken['0']+@$generatedByMe['0']+@$assignedToMe['0']); ?></td> 
                            <td><?php echo e(@$myToken['1']+@$generatedByMe['1']+@$assignedToMe['1']); ?></td> 
                            <td><?php echo e(@$myToken['2']+@$generatedByMe['2']+@$assignedToMe['2']); ?></td> 
                            <td><?php echo e(@$myToken['0']+@$myToken['1']+@$myToken['2']+@$generatedByMe['0']+@$generatedByMe['1']+@$generatedByMe['2']+@$assignedToMe['0']+@$assignedToMe['1']+@$assignedToMe['2']); ?></td> 
                        </tr>
                    </thead> 
                </table>
            </div>
        </div>
    </div> 
</div>  
<?php $__env->stopSection(); ?>

 


<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gigsoft.net/public_html/resources/views/backend/admin/user/view.blade.php ENDPATH**/ ?>
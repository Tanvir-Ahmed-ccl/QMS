<div class="content">
    <div class="row">
        <div class="col-sm-12">
            <div class="alert alert-success">
            <h3 id="completeMessage"></h3> 
            </div> 
            <div class="divider"></div>
            <div id="browse" class="hidden text-center">
                <a href="../" class="btn btn-default ">Browse  application</a>
            </div> 
        </div>
    </div>
</div>
 